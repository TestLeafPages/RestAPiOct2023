package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import week3day1.UpdateIncident;

public class DeleteIncident extends BaseClass {

	@Test(dependsOnMethods = "chaining.UpdateIncident.update")
	public void delete() {

	
		
		
		// Send the request
		Response response = RestAssured.delete(sys_id);
		
		int statusCode = response.getStatusCode();
		
		System.out.println("Status code for delete ------"+statusCode);
		
		
		 response.then().assertThat().statusCode(204);
	

	}

}
