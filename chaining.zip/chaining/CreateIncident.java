package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident extends BaseClass {
	
	@Test
	public void create() {
		
		
	// Add Request	
		
		RequestSpecification input = RestAssured.given()
		.contentType("application/json")
		.when().body("{\r\n"
				+ "  \"short_Description\": \"Test data via json\",\r\n"
				+ "  \"description\": \"Description via json\"\r\n"
				+ "}");
		
	// Send Request	
		
		  Response response = input.post();
		  
		   sys_id = response.jsonPath().get("result.sys_id");
		   incNum=response.jsonPath().get("result.number");
		   response.then().assertThat().statusCode(200);
		  
		  System.out.println("The Sys_id output is ---"+sys_id);
		  

		
		
		

		
		
	}

}
