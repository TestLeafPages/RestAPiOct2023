package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident extends BaseClass {
	
	@Test(dependsOnMethods = "chaining.CreateIncident.create")
	                          //packagename.Classname.Methodname
	public void update() {
		
	
		
	// Add Request	
		
		RequestSpecification input = RestAssured.given()
			   .contentType("application/json")
		.when().body("{\r\n"
				+ "  \"short_description\": \"Test data update via json\",\r\n"
				+ "  \"description\": \"Description update via json\"\r\n"
				+ "}");
		
	// Send Request	
		System.out.println("Sys_ID from update---"+sys_id);
		
		  Response response = input.put(sys_id);
		  response.then().assertThat().statusCode(200);
		  
		  response.prettyPrint();
		
		
		

		
		
	}

}
