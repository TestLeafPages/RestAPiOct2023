package chaining;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetAllIncident extends BaseClass {

	@Test(dependsOnMethods = "chaining.CreateIncident.create")
	public void getAll() {

		// End Point Url

		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";

		// Authentication

		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");
		
		
		// Send the request
		Response response = RestAssured.get();
		response.then().assertThat().
		body("result.number",Matchers.hasItem(incNum));
		System.out.println(incNum);
		//response.prettyPrint();
		
		
RestAssured.authentication=RestAssured.preemptive().
basic("admin", "Leaf@123");	
		
		
	

	}

}
