package chaining;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;

public class BaseClass {

	public static String sys_id;
	public static String incNum;
    @BeforeMethod
	public void setUp() {
		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";
		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");
	}
}
