package week3day2;

import java.util.concurrent.TimeUnit;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident {
	
	@Test
	public void update() {
		
	// End Point Url
		
		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";
		
	// Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");
		
	// Add Request	
		
		RequestSpecification input = RestAssured.given()
			   .contentType("application/json")
		.when().body("{\r\n"
				+ "  \"short_description\": \"Test data update via json\",\r\n"
				+ "  \"description\": \"Description update via json\"\r\n"
				+ "}");
		
	// Send Request	
		
		  Response response = input.put("59ea621d47c27110c6c87ac8f36d432a");
		  response.then().assertThat()
		  .body("result.short_description",Matchers.equalTo("Test data update via json"));
		   response.then().assertThat().body("result.number", Matchers.containsString("INC"));
		  response.prettyPrint();
		  response.getStatusLine();
		
		
		
		

		
		
	}

}
