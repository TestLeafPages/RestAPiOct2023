package week3day2;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentAssertStatusCode {
	
	@Test
	public void create() {
		
	// End Point Url
		
		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";
		
	// Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");
		
	// Add Request	
		
		RequestSpecification input = RestAssured.given()
		.contentType("application/json")
		.when().body("{\r\n"
				+ "  \"short_Description\": \"Test data via json\",\r\n"
				+ "  \"description\": \"Description via json\"\r\n"
				+ "}");
		
	// Send Request	
		
		  Response response = input.post();
		  
		 
		  
		  String sys_id = response.jsonPath().get("result.sys_id");
		  
		  System.out.println("The Sys_id output is ---"+sys_id);
		  response.then().assertThat().statusCode(Matchers.equalTo(200));
		  response.then().assertThat().statusCode(201);
		  response.prettyPrint();
		
		
		

		
		
	}

}
