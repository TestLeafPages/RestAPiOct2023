package week3day2;

import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteIncidentAssertWithCondition {

	@Test
	public void delete() {

		// End Point Url

		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";

		// Authentication

		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");
		
		
		// Send the request
		Response response = RestAssured.delete("ed66ca4d47823110c6c87ac8f36d4385");
		
		int statusCode = response.getStatusCode();
		
		if(statusCode==204)
		{
			System.out.println("Pass");
		}
		else {
			System.out.println("Fail");
		}
		
		//TestNG Assertions
		
	    Assert.assertEquals(statusCode, 204);
		
		System.out.println("Status code for delete ------"+statusCode);
		
		
		
	

	}

}
