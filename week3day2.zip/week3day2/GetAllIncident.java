package week3day2;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetAllIncident {

	@Test
	public void getAll() {

		// End Point Url

		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";

		// Authentication

		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");
		
		//INC0010085
		// Send the request
		Response response = RestAssured.get();
		
		response.then().assertThat().
		body("result.number",Matchers.hasItem("INC0010086"));
		//response.prettyPrint();
		
		
		
	

	}

}
