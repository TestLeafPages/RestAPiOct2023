package tests.rest;

import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class DynamicDataGeneration {

	@Test
	public void generateData() {
		
		Faker fake= new Faker();
		String firstName = fake.name().firstName();
		String emailAddress = fake.internet().emailAddress();
		String fullName = fake.name().fullName();
		System.out.println(firstName);
		System.out.println(emailAddress);
		System.out.println(fullName);
		
	}
}
