package tests.rest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.response.Response;
import lib.rest.RESTAssuredBase;
import lib.utils.ConfigurationManager;


public class TC002_GetInicdents extends RESTAssuredBase{
	
	@BeforeTest//Reporting
	public void setValues() {
		testCaseName = "Get Incident with Rest Assured";
		testDescription = "Get all new Incident and Verify response Code";
		nodes = "Incident";
		authors = "Shan";
		category = "REST";
	
	}

	@Test
	public void getIncident() throws FileNotFoundException, IOException {		
		
	 Response response = get(ConfigurationManager.configuration().incident());
	 verifyResponseCode(response, ConfigurationManager.configuration().responseCodeforGet());
	 response.prettyPrint();
	}


}




















