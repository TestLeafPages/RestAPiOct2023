package steps;

import java.io.File;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class StepDefinition {
	
	public static RequestSpecification inputRequest;
	public static Response response;
	

	@Given("Set the endpoint")
	public void setEndpoint() {

		RestAssured.baseURI="https://dev104044.service-now.com/api/now/table/incident";	
	}

	@And("Set the Auth")
	public void setAuth() {

		RestAssured.authentication=RestAssured.basic("admin", "f@jC1a/BbT4Y");
	}

	@When("Create incident with String body {string}")
	public void createIncident(String body) {

		 inputRequest = RestAssured.given().
				contentType("application/json").when().body(body);
		 response = inputRequest.post();

	}
	@Then("Validate response code as {int}")
	public void validateStatusCode(int code) {
		response.then().assertThat().statusCode(code);
	}
	
	@When("get all Incidents")
	public void getAllIncidents() {
		
		response=RestAssured.get();
	}
	@When("Create incident with file {string}")
	public void createIncidentFile(String fileName) {
		
		File file=new File("./src/test/resources/"+fileName);
		
		inputRequest=RestAssured.given().contentType("application/Json")
		.body(file);
		response=inputRequest.post();
	}
	
	
	
	


}
