package week1day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentWithQP {

	@Test
	public void getAll() {

		// End Point Url

		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";

		// Authentication

		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");


		//Input Request

		RequestSpecification input = RestAssured.given()
		.queryParam("sysparm_fields", "sys_id,short_description");

		// Send the request
		Response response = input.get();

		response.prettyPrint();





	}

}
