package week1day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteIncident {

	@Test
	public void delete() {

		// End Point Url

		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";

		// Authentication

		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");
		
		
		// Send the request
		Response response = RestAssured.delete("ed66ca4d47823110c6c87ac8f36d4385");
		
		int statusCode = response.getStatusCode();
		
		System.out.println("Status code for delete ------"+statusCode);
		
		
		
	

	}

}
