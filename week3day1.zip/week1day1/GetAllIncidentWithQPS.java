package week1day1;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentWithQPS {

	@Test
	public void getAll() {

		// End Point Url

		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";

		// Authentication

		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");


		//Input Request
		
		Map<String,String>queryParameters=new HashMap<String,String>();
		queryParameters.put("sysparm_fields", "sys_id,short_description");
		queryParameters.put("sysparm_limit", "3");
		
		
		RequestSpecification input = RestAssured.given()
				.queryParams(queryParameters);
		//.queryParam("sysparm_fields", "sys_id,short_description")
		//.queryParam("sysparm_limit", "3");

		// Send the request
		Response response = input.get();

		response.prettyPrint();





	}

}
