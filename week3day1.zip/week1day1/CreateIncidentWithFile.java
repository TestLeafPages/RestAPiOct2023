package week1day1;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentWithFile {

	@Test
	public void createIncident() {

		// End Point Url

		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";

		// Authentication

		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");

		File inputFile=new File("./src/test/resources/CreateIncident.json");
		
		// Input Request Body	
		RequestSpecification input = RestAssured.given().contentType("application/json")
		.when().body(inputFile);
		
		//Send Request
		
		Response response = input.post();
		
		int statusCode = response.getStatusCode();
		
		System.out.println("The status code for Create incident---"+statusCode);
		
		
		
		
		
		
		
	}
}
