package week1day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident {
	
	@Test
	public void update() {
		
	// End Point Url
		
		RestAssured.baseURI="https://dev121535.service-now.com/api/now/table/incident";
		
	// Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");
		
	// Add Request	
		
		RequestSpecification input = RestAssured.given().contentType("application/json")
		.when().body("{\r\n"
				+ "  \"short_description\": \"Test data update via json\",\r\n"
				+ "  \"description\": \"Description update via json\"\r\n"
				+ "}");
		
	// Send Request	
		
		  Response response = input.put("ed66ca4d47823110c6c87ac8f36d4385");
		  
		  
		  response.prettyPrint();
		
		
		

		
		
	}

}
