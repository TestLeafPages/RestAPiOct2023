package mocking;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RecordAndPlay {
	
	@Test
	public void create() {
		
	// End Point Url
		
		RestAssured.baseURI="http://localhost/api/now/table/incident";
		
	// Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "NQvluT54==pQ");
		
	// Add Request	
		
		RequestSpecification input = RestAssured.given()
		.contentType("application/json")
		.when().body("{\r\n"
				+ "  \"short_Description\": \"Test data via json\",\r\n"
				+ "  \"description\": \"Description via json\"\r\n"
				+ "}");
		
	// Send Request	
		
		  Response response = input.post();
		  
		  String sys_id = response.jsonPath().get("result.sys_id");
		  
		  System.out.println("The Sys_id output is ---"+sys_id);
		  
		  response.prettyPrint();
		
		
		

		
		
	}

}
