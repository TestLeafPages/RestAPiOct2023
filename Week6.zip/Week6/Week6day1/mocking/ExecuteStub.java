package mocking;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ExecuteStub {

	@Test
	public void stub() {
		
		RestAssured.baseURI="http://localhost/api/now/table/incident";
	//	RestAssured.authentication=RestAssured.basic("admin", "Leaf@123");
		
	// Add Request	
		
		RequestSpecification input = RestAssured.given()
		.contentType("application/json")
		.when().body("{\r\n"
				+ "  \"short_Description\": \"Test data via json\",\r\n"
				+ "  \"description\": \"Description via json\"\r\n"
				+ "}");
		
		 Response response = input.post();
		 response.prettyPrint();
		
	}
}
