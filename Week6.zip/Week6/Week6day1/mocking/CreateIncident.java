package mocking;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident {
	
	@Test
	public void create() {
		
	// End Point Url
		
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/incident";
		
	// Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "NQvluT54==pQ");
		
	// Add Request	
		
		RequestSpecification input = RestAssured.given()
		.contentType("application/json")
		.queryParam("sysparm_fields", "short_description")
		.when().body("{\r\n"
				+ "  \"short_Description\": \"Test data via json\",\r\n"
				+ "  \"description\": \"Description via json\"\r\n"
				+ "}");
		
	// Send Request	
		
		  Response response = input.post();
		  File schemaFile=new File("./src/test/resources/CreateIncidentSchema.json");
		  
		  response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(schemaFile));
		
		

		
		
	}

}
